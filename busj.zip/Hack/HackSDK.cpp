#include "HackSDK.h"
#include "MCPE/GameData.h"
#include "Android.h"
#include "Utils.hpp"



int (*old_ContainerManagerController__updatePreviewItem)(ContainerManagerController*, ItemInstance&, ItemInstance const&, std::string const&);

int now_ContainerManagerController__updatePreviewItem(ContainerManagerController* thiz, ItemInstance& i1, ItemInstance const& i2, std::string const& type) {
	if (moduleManager->getModule<HackSDK>()->lastItem) {
		return (*old_ContainerManagerController__updatePreviewItem)(thiz, i1, *moduleManager->getModule<HackSDK>()->lastItem, type);
	}
	return (*old_ContainerManagerController__updatePreviewItem)(thiz, i1, i2, type);
	
}

void HackSDK::initViews()
{


	Android::TextView* Transfer_InventoryActionMode = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Transfer_InventoryActionMode, "InventoryActionMode", "#FF8800", 19);
	Transfer_InventoryActionMode->setOnClickListener([=](Android::View*) {
		transferType = InventoryActionMode;
		Android::Toast("TransferType::InventoryActionMode");
		});

	Android::TextView* Transfer_ContainerMode = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Transfer_ContainerMode, "ContainerMode", "#FF8800", 19);
	Transfer_ContainerMode->setOnClickListener([=](Android::View*) {
		transferType = ContainerMode;
		Android::Toast("TransferType::ContainerMode");
		});

	Android::TextView* Transfer_ServerMode = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Transfer_ServerMode, "ServerMode", "#FF8800", 19);
	Transfer_ServerMode->setOnClickListener([=](Android::View*) {
		transferType = ServerMode;
		Android::Toast("TransferType::ServerMode");
		});

	Android::TextView* Transfer_DeleteContainerItem = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Transfer_DeleteContainerItem, "DeleteContainerItem", "#FF8800", 19);
	Transfer_DeleteContainerItem->setOnClickListener([=](Android::View*) {
		delete lastItem;
		lastItem = nullptr;
	});

	SecondWindowList.push_back(Transfer_ServerMode);
	SecondWindowList.push_back(Transfer_InventoryActionMode);
	SecondWindowList.push_back(Transfer_ContainerMode);
	SecondWindowList.push_back(Transfer_DeleteContainerItem);
}

HackSDK::HackSDK()
{
	ModuleType = "Item";
	UIType = 1;
}

const char* HackSDK::GetName()
{
	return "HackSDK";
}

const char* HackSDK::getMenuName()
{
	return "TransferType";
}

void HackSDK::MinecraftInit()
{
	HackSDK::FastHook(GameData::FunctionPtr::const_ContainerManagerController__updatePreviewItem, (void*)now_ContainerManagerController__updatePreviewItem, (void**)&old_ContainerManagerController__updatePreviewItem);
}

void HackSDK::OnTick(Actor* act)
{
	LocalPlayer* lp = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer();
	if (lp) {
		if (act->getRuntimeID() == lp->getRuntimeID()) {
			if (act != lp) {
				remoteLocalPlayer = (Player*)act;
			}
		}
	}

	if (act != lp)return;
	lpTickEventsMtx.lock();
	for (auto it = lpTickEvents.begin(); it != lpTickEvents.end(); it = it + 1) {
		(*it)();
	}
	lpTickEvents.clear();
	lpTickEventsMtx.unlock();
}

void HackSDK::OnNewGame(std::string const& ip)
{
	remoteLocalPlayer = nullptr;
	delete lastItem;
	lastItem = nullptr;
}

void HackSDK::destroyBlock(BlockPos const& bp, int rot)
{
	LocalPlayer* lp = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer();

	lp->gamemode->destroyBlock(bp, rot);

	lp->getPlayerActionComponent()->addStartDestroyBlock(bp, rot);
	lp->getPlayerActionComponent()->addPredictDestroyBlock(bp, rot);
	lp->getPlayerActionComponent()->addCrackBlock(bp, rot);
	lp->getPlayerActionComponent()->addStopDestroyBlock(bp, rot);

	lp->sendInput();
}

bool HackSDK::onGroundCheck()
{
	LocalPlayer* lp = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer();
	Vec3 below(*lp->getPos());
	below.y = below.y - 2.0f;

	if (lp->getRegion()->getBlock(below)->_BlockLegacy->getBlockItemId() != 0) {
		return true;
	}
	return false;
}

bool HackSDK::isRealPlayer(Player* p)
{
	std::string name = p->getName();
	if (name.size() < 2)return false;
	if (strstr(name.c_str(), "商") && strstr(name.c_str(), "店"))return false;
	if (strstr(name.c_str(), "回") && strstr(name.c_str(), "城"))return false;
	if (p->getHealth() <= 0 || p->getHealth() > 10000)return false;
	return true;
}

void HackSDK::FastHook_realAddr(void* addr, void* now, void** old)
{
	registerInlineHook((uint32_t)addr, (uint32_t)now, (uint32_t**)old);
	inlineHook((uint32_t)addr);
}

void HackSDK::FastHook(uint32_t addr, void* now, void** old)
{
	uint32_t address = GameData::libinfo.head + addr + 1;
	registerInlineHook(address, (uint32_t)now, (uint32_t**)old);
	inlineHook(address);
}


void HackSDK::transferItem(ItemStack& old, ItemStack& now, uint32_t slot)
{
	if (autoTransfer == false) {
		return;
	}

	if (transferType == InventoryActionMode) {

#ifdef Internal

		InventorySource source1(0, 0, 0);
		InventoryAction action1(&source1, slot, old, *GameData::emptyItem);
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->manager.addAction(action1, false);

		InventorySource source2(99999, -5, 0);
		InventoryAction action2(&source2, 0, *GameData::emptyItem, old);
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->manager.addAction(action2, false);

		InventorySource source3(99999, -5, 0);
		InventoryAction action3(&source3, 0, now, *GameData::emptyItem);
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->manager.addAction(action3, false);

		InventorySource source4(0, 0, 0);
		InventoryAction action4(&source4, slot, *GameData::emptyItem, now);
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->manager.addAction(action4, false);
		
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->updateInventoryTransactions();
#endif
	}
	else if (transferType == ContainerMode) {
		if (lastItem) {
			delete lastItem;
		}
		lastItem = new ItemInstance(now);
	}
	else if (transferType == ServerMode) {
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->getSupplies()->setItem(slot, now, 0, false);
		if (remoteLocalPlayer) {
			remoteLocalPlayer->getSupplies()->setItem(slot, now, 0, false);
		}
		
	}
}

void HackSDK::OnCmd(std::vector<std::string>* cmd)
{
	 if ((*cmd)[0] == ".AutoTransfer") {
		if (cmd->size() < 2)return;
		if ((*cmd)[1] == "true") {
			moduleManager->executedCMD = true;
			autoTransfer = true;
		}
		else if ((*cmd)[1] == "false") {
			moduleManager->executedCMD = true;
			autoTransfer = false;
		}
	}
	 else if ((*cmd)[0] == ".TransferType") {
		 if (cmd->size() < 2)return;
		 transferType = (TransferType)atoi((*cmd)[1].c_str());
		 autoTransfer = false;
		 moduleManager->executedCMD = true;
	 }
	 else if ((*cmd)[0] == ".DeleteContainerItem") {
		 moduleManager->executedCMD = true;
		 delete lastItem;
		 lastItem = nullptr;
	 }
}

void HackSDK::addLocalPlayerTickEvent(std::function<void(void)> call)
{
	lpTickEventsMtx.lock();
	lpTickEvents.push_back(call);
	lpTickEventsMtx.unlock();
}

void HackSDK::lookAt(Vec3 pos,float smooth)
{
	LocalPlayer* lp = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer();
	Vec3* orgin = lp->getPos();
	if (orgin->x == pos.x) {
		pos.x = pos.x + 0.001f;
	}
	if (orgin->z == pos.z) {
		pos.z = pos.z + 0.001f;
	}
	float yaw = 0.0f;
	float pitch = lp->rot.pitch;
	float ZOP = 0.0f;

	
	float PH = fabsf(pos.x - orgin->x);
	float OH = fabsf(pos.z - orgin->z);
	float POH = atanf(PH / OH) * 180.0f/PI;

	if (pos.z > orgin->z) {//Z正半轴
		if (pos.x > orgin->x) {//第一象限
			ZOP = -POH;
		}
		else {//第四象限
			ZOP = POH;
		}
	}
	else {//Z负半轴
		if (pos.x > orgin->x) {//第二象限
			ZOP = -(180.0f - POH);
		}
		else {//第三象限
			ZOP = 180.0f - POH;
		}
	}
	yaw = ZOP - lp->rot.yaw;

	float PT = fabsf(orgin->y - pos.y);
	float OT = sqrtf(powf(orgin->x - pos.x, 2) + powf(orgin->z - pos.z, 2));
	float POT = atanf(PT / OT) * 180.0f / PI;
	if (orgin->y < pos.y) {
		POT = -POT;
	}
	
	pitch = lp->rot.pitch - POT;

	Vec2 rot(pitch / smooth, yaw / smooth);
	lp->_applyTurnDelta(rot);
}

void HackSDK::Enchant(ItemStackBase* item, short id, short lvl) {
	if (item->userData == 0) {
		CompoundTag* newUserData = new CompoundTag;
		item->userData = newUserData;
	}
	CompoundTag* nbt = item->userData;
	if (nbt->contains("ench")) {
		ListTag* enchList = nbt->getList("ench");
		size_t size = enchList->size();
		bool flag = false;
		for (int i = 0; i < size; ++i) {
			CompoundTag* ench = enchList->getCompound(i);
			if (ench->getShort("id") == id) {
				ench->remove("id");
				ench->remove("lvl");
				ench->putShort("id", id);
				ench->putShort("lvl", lvl);
				flag = true;
			}
		}
		if (flag == false) {
			std::unique_ptr<CompoundTag> enchData(new CompoundTag);
			enchData->putShort("id", id);
			enchData->putShort("lvl", lvl);
			enchList->add(std::move(enchData));
		}
	}
	else {
		std::unique_ptr<CompoundTag> enchData(new CompoundTag);
		enchData->putShort("id", id);
		enchData->putShort("lvl", lvl);
		std::unique_ptr<ListTag> enchList(new ListTag);
		enchList->add(std::move(enchData));
		nbt->put("ench", std::move(enchList));
	}
}

std::vector<Actor*> HackSDK::getActorList()
{

	std::vector<Actor*> all;
	Dimension* dim = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->getDimension();
	dim->forEachPlayer([&](Player& a) {
		all.push_back(&a);
		return true;
		});
	dim->getEntityIdMap()->forEachEntity([&](Actor& a) {
		all.push_back(&a);
		});
	return all;
}

void HackSDK::drawText(MinecraftUIRenderContext& ctx, const vec2_t pos, std::string const& text, const mce::Color& color, Font* font, float textSize, float alpha)
{
	float posF[4];
	posF[0] = pos.x;
	posF[1] = pos.x + 1000;
	posF[2] = pos.y;
	posF[3] = pos.y + 1000;
	TextMeasureData textMeasure{};
	memset(&textMeasure, 0, sizeof(TextMeasureData));
	textMeasure.textSize = textSize;
	ctx.drawText(*font, posF, text, color, alpha, textMeasure);
}

void HackSDK::drawLine(MinecraftUIRenderContext& ctx, const vec2_t& start, const vec2_t& end, float lineWidth, mce::Color const& color)
{
	ScreenContext* screenCtx = ctx.getScreenContext();

	float modX = 0 - (start.y - end.y);
	float modY = start.x - end.x;

	float len = sqrtf(modX * modX + modY * modY);

	modX /= len;
	modY /= len;
	modX *= lineWidth;
	modY *= lineWidth;


	screenCtx->tesselator->begin(3, 6);
	screenCtx->tesselator->color(color);

	screenCtx->tesselator->vertex(start.x + modX, start.y + modY, 0);
	screenCtx->tesselator->vertex(start.x - modX, start.y - modY, 0);
	screenCtx->tesselator->vertex(end.x - modX, end.y - modY, 0);

	screenCtx->tesselator->vertex(start.x + modX, start.y + modY, 0);
	screenCtx->tesselator->vertex(end.x + modX, end.y + modY, 0);
	screenCtx->tesselator->vertex(end.x - modX, end.y - modY, 0);

	mce::MaterialPtr* uiMaterial = mce::MaterialPtr::getUIMaterialPtr();

	MeshHelpers::renderMeshImmediately(*screenCtx, *(screenCtx->tesselator), *uiMaterial);
}

void HackSDK::drawLine3D(MinecraftUIRenderContext& ctx, glmatrixf* matrix, vec3_t const& cam, vec2_t const& fov, vec2_t const& screenSize, vec3_t const& start, vec3_t const& end, float lineWdith, mce::Color const& color)
{
	vec2_t start2;
	if (matrix->OWorldToScreen(cam, start, start2, fov, screenSize) == true) {
		vec2_t end2;
		if (matrix->OWorldToScreen(cam, end, end2, fov, screenSize) == true) {
			drawLine(ctx, start2, end2, lineWdith, color);
		}
	}
}

void HackSDK::drawBox3D(MinecraftUIRenderContext& ctx, glmatrixf* matrix, vec3_t const& cam, vec2_t const& fov, vec2_t const& display, vec3_t const& from, vec3_t const& to, float lineWdith, mce::Color const& color)
{
	drawLine3D(ctx, matrix, cam, fov, display, from, vec3_t(to.x, from.y, from.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, from, vec3_t(from.x, to.y, from.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, from, vec3_t(from.x, from.y, to.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, vec3_t(to.x, from.y, from.z), vec3_t(to.x, to.y, from.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, vec3_t(to.x, from.y, from.z), vec3_t(to.x, from.y, to.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, vec3_t(from.x, to.y, from.z), vec3_t(to.x, to.y, from.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, vec3_t(from.x, to.y, from.z), vec3_t(from.x, to.y, to.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, to, vec3_t(to.x, to.y, from.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, to, vec3_t(to.x, from.y, to.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, to, vec3_t(from.x, to.y, to.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, vec3_t(from.x, from.y, to.z), vec3_t(from.x, to.y, to.z), lineWdith, color);
	drawLine3D(ctx, matrix, cam, fov, display, vec3_t(from.x, from.y, to.z), vec3_t(to.x, from.y, to.z), lineWdith, color);
}

Player* HackSDK::getPlayerByName(std::string const& name)
{
	Player* p = nullptr;
	GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->getDimension()->forEachPlayer([&](Player& object) {
		if (object.getName() == name) {
			p = &object;
		}
		return true;
	});
	return p;
}

void* HackSDK::getGlobalPtr(std::string const& fName)
{
	std::stringstream addrPath;
	addrPath << "/data/data/" << GameData::getPackageName() << "/"<<fName;
	std::stringstream addr;
	addr << Utils::readFileIntoString(addrPath.str().c_str());
	void* ptr;
	addr >> ptr;
	return ptr;
}

void HackSDK::setGlobalPtr(std::string const& fName, void* ptr)
{
	std::stringstream addrPath;
	addrPath << "/data/data/" << GameData::getPackageName() << "/"<<fName;
	if (access(addrPath.str().c_str(), F_OK) == 0) {
		remove(addrPath.str().c_str());
	}

	std::stringstream addr;
	addr << ptr;

	Utils::WriteStringToFile(addrPath.str().c_str(), addr.str());
}
