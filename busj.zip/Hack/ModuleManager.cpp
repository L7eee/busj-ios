#include "ModuleManager.h"
#include "MCPE/Listener.h"
#include "MCPE/GameData.h"
#include "MCPE/MCHOOK/hookClientInstanceScreenModelSendChatMessage.h"
#include  "json/json.h"
#include  "Android.h"
#include  "Killaura.h"
#include "ForceOpenSign.h"
#include "ActorEventManager.h"
#include "PyManager.h"
#include  "Script.h"
#include  "Menu.h"
#include "Teleport.h"
#include  "JetPack.h"
#include  "HackSDK.h"
#include  "Network.h"
#include  "Chat.h"
#include  "SkinManager.h"
#include "AC.h"
#include "Bhop.h"
#include "NightVision.h"
#include "ClickDestroy.h"
#include "PluginInterface.h"
#include "Music.h"
#include "Enchant.h"
#include "ContainerHack.h"
#include  "AutoDestroy.h"
#include  "Debug.h"
#include "ResourceManager.h"
#include  "Destroy.h"
#include  "AntiVoid.h"
#include "Server.h"
#include "Netease.h"
#include "Hitbox.h"
#include "NoKnockback.h"
#include "Patch.h"
#include "Pos.h"
#include "Water.h"
#include "FastBuilder.h"
#include "ItemTool.h"
#include "Scaffold.h"
#include "ClientPacketManager.h"
#include "ShowCommand.h"
#include "FreeCam.h"
#include "Xray.h"
#include "AutoAim.h"
#include "XpOrbSpawner.h"
#include "ESP.h"
#include "World.h"
#include <thread>
#include <algorithm>

#ifdef T3
#include "http/http.h"
#endif 


ModuleManager* moduleManager = new ModuleManager;

bool MinecraftInit = false;

void ModuleListener(std::string s) {
	Json::Value value;
	Json::Reader reader;
	reader.parse(s, value);
	
	if (value.isMember("MCCall") && value["MCCall"]["Type"] == "Actor::normalTick" && value["MCCall"]["State"] == "BeforeCall") {
		Actor* object = reinterpret_cast<Actor*>(value["MCCall"]["Args"]["object"].asUInt());
		for (auto it = moduleManager->ModuleList.begin(); it != moduleManager->ModuleList.end(); it = it + 1) {
			(*it)->OnTick(object);
		}
	}
	else if (value.isMember("MCEvent") && value["MCEvent"] == "Init") {
		MinecraftInit = true;
	}
	else if (value.isMember("MCCall") && value["MCCall"]["Type"] == "ClientInstanceScreenModel::sendChatMessage" && value["MCCall"]["State"] == "BeforeCall") {
		moduleManager->executeModuleCommand(value["MCCall"]["Args"]["ChatMessage"].asString());
	}
	else if (value.isMember("MCCall") && value["MCCall"]["Type"] == "MinecraftGame::_update" && value["MCCall"]["State"] == "BeforeCall") {
		MinecraftGame* object = reinterpret_cast<MinecraftGame*>(value["MCCall"]["Args"]["object"].asUInt());
		for (auto it = moduleManager->ModuleList.begin(); it != moduleManager->ModuleList.end(); it = it + 1) {
			(*it)->OnMCMainThreadTick(object);
		}
	}
	else if (value.isMember("MCCall") && value["MCCall"]["Type"] == "LoopbackPacketSender::sendToServer") {
		Packet* networkPacketPtr = reinterpret_cast<Packet*>(value["MCCall"]["Args"]["data"].asUInt());
		if (value["MCCall"]["State"] == "BeforeCall") {
			for (auto it = moduleManager->ModuleList.begin(); it != moduleManager->ModuleList.end(); it = it + 1) {
				(*it)->OnSendPacket(networkPacketPtr);
			}
		}
		else {
			for (auto it = moduleManager->ModuleList.begin(); it != moduleManager->ModuleList.end(); it = it + 1) {
				(*it)->AfterPacket(networkPacketPtr);
			}
		}
	}
	else if (value.isMember("MCCall") && value["MCCall"]["Type"] == "ScreenView::render" && value["MCCall"]["State"] == "BeforeCall") {
		MinecraftUIRenderContext* ctx = reinterpret_cast<MinecraftUIRenderContext*>(value["MCCall"]["Args"]["ctxPtr"].asUInt());
		for (auto it = moduleManager->ModuleList.begin(); it != moduleManager->ModuleList.end(); it = it + 1) {
			(*it)->OnRender(ctx);
		}
	}
	else if (value.isMember("MCCall") && value["MCCall"]["Type"] == "GameMode::attack" && value["MCCall"]["State"] == "BeforeCall") {
		GameMode* object = reinterpret_cast<GameMode*>(value["MCCall"]["Args"]["object"].asUInt());
		Actor* target = reinterpret_cast<Actor*>(value["MCCall"]["Args"]["target"].asUInt());
		for (auto it = moduleManager->ModuleList.begin(); it != moduleManager->ModuleList.end(); it = it + 1) {
			(*it)->OnAttack(object,target);
		}
	}
	else if (value.isMember("MCCall") && value["MCCall"]["Type"] == "GameMode::buildBlock" && value["MCCall"]["State"] == "BeforeCall") {
		GameMode* object = reinterpret_cast<GameMode*>(value["MCCall"]["Args"]["object"].asUInt());
		BlockPos& buildPos = *reinterpret_cast<BlockPos*>(value["MCCall"]["Args"]["buildPos"].asUInt());
		int8_t rot = (int8_t)(value["MCCall"]["Args"]["buildRot"].asUInt());
		for (auto it = moduleManager->ModuleList.begin(); it != moduleManager->ModuleList.end(); it = it + 1) {
			(*it)->OnBuild(object,buildPos,rot);
		}
	}
}

void ModuleManager::executeModuleCommand(std::string const& s)
{
#ifdef HideUI
	std::string first;
	for (auto it = s.begin(); it != s.end(); it = it + 1) {
		first.push_back(tolower(*it));
	}
	if (strstr(first.c_str(), "atri") || strstr(first.c_str(), "plague inc")) {
		Android::changeUIState(false);
		GameData::getNowMinecraftGame()->getPrimaryGuiData()->displaySystemMessage("[HackCMD]UI enabled!", "");
		MCHook::noMessageThisTime = true;
		return;
	}
#endif
	std::vector<std::string> res;
	std::string result;
	std::stringstream input(s);
	while (input >> result)res.push_back(result);

	if (res[0] == ".SaveConfig") {
		MCHook::noMessageThisTime = true;
		GameData::getNowMinecraftGame()->getPrimaryGuiData()->displaySystemMessage("[HackCMD]Config saved!", "");
		loader->save(this);
		return;
	}

	if (canUseCommand) {
		std::string CMDStr = s;
		const char* CMDHead = ".";
		if (CMDStr.compare(0, strlen(CMDHead), CMDHead) == 0) {
			MCHook::noMessageThisTime = true;
			executedCMD = false;

			for (auto it = ModuleList.begin(); it != ModuleList.end(); it = it + 1) {
				(*it)->OnCmd(&res);
			}

			if (executedCMD == true) {
				GameData::getNowMinecraftGame()->getPrimaryGuiData()->displaySystemMessage("[HackCMD]Command executed success!", "");

			}
			else{
				GameData::getNowMinecraftGame()->getPrimaryGuiData()->displaySystemMessage("[HackCMD]Command executed error!", "");
			}
		}
		else {
			for (auto it = ModuleList.begin(); it != ModuleList.end(); it = it + 1) {
				(*it)->OnSendChat(CMDStr);
			}
		}
	}
}

void ModuleManager::init()
{
	moduleManager->initModules();
	for (auto it = ModuleList.begin(); it != ModuleList.end(); it = it + 1) {
		(*it)->UiInit();
	}
	std::thread thread([=]() {
		while (true) {
			if (MinecraftInit) {
				for (auto it = moduleManager->ModuleList.begin(); it != moduleManager->ModuleList.end(); it = it + 1) {
					(*it)->MinecraftInit();
				}
				break;
			}
			usleep(100);
		}
		});
	thread.detach();
}

void ModuleManager::initModules()
{
	
	ModuleList.push_back(std::shared_ptr<Module>(new Patch()));
	ModuleList.push_back(std::shared_ptr<Module>(new Scaffold()));
	ModuleList.push_back(std::shared_ptr<Module>(new Killaura()));
	ModuleList.push_back(std::shared_ptr<Module>(new Bhop()));
	ModuleList.push_back(std::shared_ptr<Module>(new ESP()));
	ModuleList.push_back(std::shared_ptr<Module>(new AutoAim()));
	ModuleList.push_back(std::shared_ptr<Module>(new AutoDrestroy()));
	ModuleList.push_back(std::shared_ptr<Module>(new ClickDestroy()));
	ModuleList.push_back(std::shared_ptr<Module>(new ForceOpenSign()));
	ModuleList.push_back(std::shared_ptr<Module>(new ShowCommand()));
	ModuleList.push_back(std::shared_ptr<Module>(new Water()));
	ModuleList.push_back(std::shared_ptr<Module>(new Netease()));
	ModuleList.push_back(std::shared_ptr<Module>(new FreeCam()));
	ModuleList.push_back(std::shared_ptr<Module>(new World()));
	ModuleList.push_back(std::shared_ptr<Module>(new ActorEventManager()));
#ifdef Internal
	ModuleList.push_back(std::shared_ptr<Module>(new Server()));
	ModuleList.push_back(std::shared_ptr<Module>(new Debug()));
#endif
	ModuleList.push_back(std::shared_ptr<Module>(new MenuController()));
	ModuleList.push_back(std::shared_ptr<Module>(new Script()));
	ModuleList.push_back(std::shared_ptr<Module>(new Xray()));
	ModuleList.push_back(std::shared_ptr<Module>(new AntiVoid()));
	ModuleList.push_back(std::shared_ptr<Module>(new Teleport()));
	ModuleList.push_back(std::shared_ptr<Module>(new JetPack()));
	ModuleList.push_back(std::shared_ptr<Module>(new HackSDK()));
	ModuleList.push_back(std::shared_ptr<Module>(new Network()));
	ModuleList.push_back(std::shared_ptr<Module>(new Chat()));
	ModuleList.push_back(std::shared_ptr<Module>(new SkinManager()));
	ModuleList.push_back(std::shared_ptr<Module>(new XpOrbSpawner()));
	ModuleList.push_back(std::shared_ptr<Module>(new AC()));
	ModuleList.push_back(std::shared_ptr<Module>(new ContainerHack()));
	ModuleList.push_back(std::shared_ptr<Module>(new Enchant()));
	ModuleList.push_back(std::shared_ptr<Module>(new Destroy()));
	ModuleList.push_back(std::shared_ptr<Module>(new Hitbox()));
	ModuleList.push_back(std::shared_ptr<Module>(new NightVision()));
	ModuleList.push_back(std::shared_ptr<Module>(new NoKnockback()));
	ModuleList.push_back(std::shared_ptr<Module>(new Pos()));
	ModuleList.push_back(std::shared_ptr<Module>(new ItemTool()));
	ModuleList.push_back(std::shared_ptr<Module>(new PluginHelper()));
	ModuleList.push_back(std::shared_ptr<Module>(new ClientPacketManager()));
	ModuleList.push_back(std::shared_ptr<Module>(new ResourceManager()));
	ModuleList.push_back(std::shared_ptr<Module>(new Music()));
	ModuleList.push_back(std::shared_ptr<Module>(new FastBuilder()));
	ModuleList.push_back(std::shared_ptr<Module>(new PyManager()));

	loader->load(this);
}

ModuleManager::ModuleManager() {
	Listener::addFunc(ModuleListener);
	loader = new ConfigLoader;
}




void ModuleManager::jniOnLoad(JavaVM* vm)
{
	Android::Init(vm);
#ifdef  HideUI
	Android::changeUIState(true);
#endif 


#ifndef T3
	init();
#endif 
#ifdef T3
	Android::Window* win = Android::Window::newWindow();
	win->setCanMove(true);
	win->setCanShowKeyboard(true);
	win->setOrientation(1);

	Android::EditText* km = Android::EditText::newEditText();
	UIUtils::updateEditTextData(km, "请输入卡密");

	Android::TextView* yz = Android::TextView::newTextView();
	UIUtils::updateTextViewData(yz, "确定", "#FF8800", 19);

	win->addView(*km);
	win->addView(*yz);

	yz->setOnClickListener([=](Android::View*) {
		std::thread thread([=]() {
			std::stringstream msg;
			msg << "kami=" << km->text << "&imei=" << Android::getHWId();
			char* result = http_post("http://w.amtess.cn/320D7EB19B5B23E0", msg.str().c_str());
			if (strstr(result, "登录成功")) {
				win->deleteWindow();
				km->release();
				yz->release();
				init();
			}
			Android::Toast(result);
			free(result);
		});
		thread.detach();
	});
#endif
}

void ModuleManager::OnNewGame(std::string const& ip)
{
	for (auto it = ModuleList.begin(); it != ModuleList.end(); it = it + 1) {
		(*it)->OnNewGame(ip);
	}
}



void Module::loadConfig(Json::Value const& config)
{
	if (config.isMember(GetName())) {
		Json::Value subConf = config[GetName()];
		Json::Value::Members mem = subConf.getMemberNames();
		for (auto it = mem.begin(); it != mem.end(); it++) {
			auto  t = subConf[*it].type();
			if (getConfigObject(*it)) {
				if (t == Json::ValueType::intValue || t == Json::ValueType::uintValue) {
					*(int*)getConfigObject(*it)->ptr = subConf[*it].asInt();
				}
				else if (t == Json::ValueType::realValue) {
					*(float*)getConfigObject(*it)->ptr = subConf[*it].asFloat();
				}
				else if (t == Json::ValueType::booleanValue) {
					*(bool*)getConfigObject(*it)->ptr = subConf[*it].asBool();
				}
				else if (t == Json::ValueType::stringValue) {
					*(std::string*)getConfigObject(*it)->ptr = subConf[*it].asString();
				}
			}
		}
	}
}

void Module::saveConfig(Json::Value& config)
{
	for (auto i : configList) {
		if (i->moduleName == GetName()) {
			if (i->type == typeid(int).name() || i->type == typeid(uint32_t).name()) {
				config[GetName()][i->configName] = *(int*)i->ptr;
			}
			else if (i->type == typeid(float).name()) {
				config[GetName()][i->configName] = *(float*)i->ptr;
			}
			else if (i->type == typeid(bool).name()) {
				config[GetName()][i->configName] = *(bool*)i->ptr;
			}
			else if (i->type == typeid(std::string).name()) {
				config[GetName()][i->configName] = *(std::string*)i->ptr;
			}
		}
	}
}

ConfigObject* Module::getConfigObject(std::string const& name)
{
	for (auto i : configList) {
		if (i->configName == name) {
			return i;
		}
	}
	logMessage("can not get config object " + name);
	return nullptr;
}

void Module::logMessage(std::string const& message)
{
	const char* path = "/sdcard/ClientLog.txt";
	std::stringstream os;
	struct tm* t;
	struct timeval tv;
	struct timezone tz;
	gettimeofday(&tv, &tz);
	t = localtime(&tv.tv_sec);
	os << "<" << GetName() << ">" << "<" << 1900 + t->tm_year << ":" << t->tm_mon << ":" << t->tm_mday << ":" << t->tm_hour << ":" << t->tm_min << ":" << t->tm_sec << ">" << message;
	Utils::WriteStringToFile(path, os.str());
}

void Module::MinecraftInit()
{
}

void Module::UiInit()
{
}


const char* Module::GetName()
{
	return "DefaultName";
}

void Module::OnTick(Actor* act)
{
}

void Module::OnSendPacket(Packet* packet)
{
}

void Module::AfterPacket(Packet* packet)
{
}

void Module::OnRender(MinecraftUIRenderContext* ctx)
{
}

void Module::OnCmd(std::vector<std::string>* cmd)
{
}

void Module::OnAttack(GameMode* object,Actor* act)
{
}

void Module::OnBuild(GameMode* object,BlockPos const& pos, int rot)
{
}

void Module::OnNewGame(std::string const& ip)
{
}

void Module::OnSendChat(std::string const& msg)
{
}

void Module::OnMCMainThreadTick(MinecraftGame* mcgame)
{
}




ConfigObject::ConfigObject(void* val, std::string name, Module* m, std::string typeName)
{
	ptr = val;
	configName = name;
	type = typeName;
	moduleName = m->GetName();
}

std::string ConfigLoader::getPath()
{
	return "/sdcard/moduleConfig.txt";
}

void ConfigLoader::load(ModuleManager* manager)
{
	Json::Reader reader;
	Json::Value value;
	reader.parse(Utils::readFileIntoString(getPath().c_str()), value);
	for (auto i : manager->ModuleList) {
		i->loadConfig(value);
	}
}

void ConfigLoader::save(ModuleManager* manager)
{
	Json::Value value;
	for (auto i : manager->ModuleList) {
		i->saveConfig(value);
	}
	Utils::DeleteFile(getPath().c_str());
	Utils::WriteStringToFile(getPath().c_str(), value.toStyledString());
}
