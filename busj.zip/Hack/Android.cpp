#include <stdio.h>
#include <jni.h>
#include <stddef.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <stddef.h>
#include <dlfcn.h>
#include <dirent.h>
#include <stdlib.h>
#include <string>
#include <mutex>
#include  "json/json.h"
#include <sstream>
#include "MCPE/GameData.h"
#include "FunctionTool/FunctionTool.h"
#include "Utils.hpp"
#include "Android.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <net/if.h>
#include <arpa/inet.h>
#include "ModuleManager.h"
#include "HackSDK.h"
#include "Raknet/SuperFastHash.h"



namespace Android{

	void loadLibrary(std::string const& libname) {

		JNIEnv* jni_env = nullptr;
		bool k = false;
		GameData::VM_0->GetEnv((void**)&jni_env, JNI_VERSION_1_6);
		if (jni_env == nullptr) {
			k = true;
			GameData::VM_0->AttachCurrentThread(&jni_env, NULL);
		}

		std::stringstream bufferPath;
		bufferPath << "/data/data/" << GameData::getPackageName() << "/MyLibs";
		if (opendir(bufferPath.str().c_str()) == 0) {
			Utils::folder_mkdirs(bufferPath.str().c_str());
		}

		auto sv = Utils::split(libname, "/");
		std::string fileName = sv[sv.size() - 1];

		std::stringstream realPath;
		realPath << bufferPath.str() << "/" << fileName;

		if (access(realPath.str().c_str(), F_OK) == 0) {
			remove(realPath.str().c_str());
		}

		Utils::copyFile(libname.c_str(), realPath.str().c_str());

		chmod(realPath.str().c_str(), 0777);

		loadPluginLib(jni_env, realPath.str().c_str());

		remove(realPath.str().c_str());

		if (k) {
			GameData::VM_0->DetachCurrentThread();
		}
	}

	std::string getHWId() {
		FILE* res = popen("stat -f /", "r");
		char res_cache[8][1024];
		char res_final[1024];
		memset(res_final, 0, 1024);
		int line = 0;
		while (fgets(res_cache[line], 1024, res) != NULL) {
			line++;
		}
		pclose(res);
		sscanf(res_cache[1], " ID: %s ", &res_final);

		const char* uidPath = "/sdcard/nsc.dat";
		if (access(uidPath, F_OK) != 0) {
			srand(time(0));
			int uid = rand();
			Utils::WriteStringToFile(uidPath, Utils::asString(uid));
		}

		std::stringstream full;
		full << Utils::readFileIntoString("/sys/class/net/wlan0/address") << Utils::readFileIntoString("/proc/cmdline") << res_final << Utils::readFileIntoString(uidPath);
		uint32_t hash = SuperFastHash(full.str().c_str(), full.str().size());

		return Utils::asString(hash);
	}


	bool isInited = false;

	void View::setOnClickListener(std::function<void(View*)> f) {
		onClickListener = f;
	}

	void View::setOnLongClickListener(std::function<void(View*)> f) {
		onLongClickListener = f;
	}

	void EditText::setTextChangedListener(std::function<void(EditText*, std::string)> f) {
		textChangedListener = f;
	}


	void Switch::setOnCheckedChangeListener(std::function<void(Switch*, bool)> f)
	{
		onCheckedChangeListener = f;
	}

	void EditText::handle(std::string s) {
		text = s;
		if (textChangedListener != nullptr) {
			textChangedListener(this, s);
		}
	}

	class Interface* interface;
#ifdef SOCKET
	class Interface{
		public:
			bool ui_isStopped = false;

			void changeState(bool b) {
				ui_isStopped = b;
			}

		static void* updateUI(void* t){
			Interface* thiz = (Interface*)t;
			sleep(8);
			while(true){
				
				usleep(100000);
				if (thiz->ui_isStopped == false) {
					Json::Value val;
					(thiz->mtx).lock();
					if (thiz->l.size() == 0) {
						(thiz->mtx).unlock();
						continue;
					}
					for (int i = 0; i < (thiz->l).size(); i = i + 1) {
						val[i] = (thiz->l)[i];
					}
					(thiz->l).clear();
					(thiz->mtx).unlock();
					thiz->send(val);
				}
			}
			return nullptr;
		}
		void createUIUpdateThread(void){
			pthread_t ui_update;
			pthread_create(&ui_update, 0, updateUI,this);
		}
		Interface(void){
			sockfd = socket(AF_INET, SOCK_DGRAM, 0);
			sockaddr_in  local_addr = {0};
			local_addr.sin_family  = AF_INET;
			local_addr.sin_port	= htons(11111); 
			local_addr.sin_addr.s_addr = INADDR_ANY;
			int ret = ::bind(sockfd,(sockaddr*)&local_addr,sizeof(local_addr));
			if(ret == -1){
				puts("UDPServer bind error");
			}
			DataBuffer = new char[MaxDataSize];
			
		}
		~Interface(void){
			::close(sockfd);
			delete[] DataBuffer;
		}
		std::string recv(void){
			sockaddr_in addr;
			memset(DataBuffer,0,MaxDataSize);
			int len = sizeof(addr);
			int ret = ::recvfrom(sockfd, DataBuffer, MaxDataSize, 0, (sockaddr *)&addr, &len);
			if(ret == -1){
				return "";
			}
			else{
				return DataBuffer;
			}
		}
		Json::Value recvJson(void){
			Json::Reader reader;
			Json::Value value;
			reader.parse(recv(), value);
			return value;
		}
		void send(std::string s){
			
			sockaddr_in src_addr;
			src_addr.sin_family  = AF_INET;
			src_addr.sin_port	= htons(11112); 
			src_addr.sin_addr.s_addr = INADDR_ANY;
			src_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
			int len = sizeof(src_addr);
			::sendto(sockfd, s.c_str(), s.size(), 0, (sockaddr *)&src_addr, len);
		}
		void send(Json::Value v){
			send(v.toStyledString());
		}
		void add(Json::Value v){
			mtx.lock();
			l.push_back(v);
			mtx.unlock();
		}
		std::mutex mtx;
		std::vector<Json::Value> l;
		char* DataBuffer;
		const int MaxDataSize = 1024*1024;
		int sockfd;
		
	};


	void* Recv(void* p) {
		while (true) {
			Json::Value val = interface->recvJson();
			handleJson(val);
			usleep(2000);
		}
		return nullptr;
	}

	
	
	pthread_t RecvThread;

#endif 


#ifdef JNI
	inline jstring str2jstring(JNIEnv* env, std::string str)
	{
		return env->NewStringUTF(str.c_str());
	}

	inline std::string jstring2str(JNIEnv* env, jstring jstr)
	{
		const char* v = env->GetStringUTFChars(jstr, 0);
		std::string res = v;
		env->ReleaseStringUTFChars(jstr, v);
		return res;
	}

	void JNICALL NativeUIEvent(JNIEnv* env, jobject jobj,jstring str) {

		Json::Reader reader;
		Json::Value value;
		reader.parse(jstring2str(env,str), value);
		handleJson(value);
	}

	class Interface {
	public:

		bool ui_isStopped = false;

		jclass UIClass;
		std::recursive_mutex mtx;
		Interface(JavaVM* vm) {

			JNIEnv* jni_env = nullptr;
			vm->GetEnv((void**)&jni_env, JNI_VERSION_1_6);
			jclass localClass = jni_env->FindClass("com/UIService");
			if (localClass == 0) {

				if (jni_env->ExceptionCheck()) {
					jni_env->ExceptionDescribe();
					jni_env->ExceptionClear();
				}

				UIClass = *(jclass*)HackSDK::getGlobalPtr("UIClass");
			}
			else {
				UIClass = (jclass)jni_env->NewGlobalRef(localClass);
			}
			jni_env->DeleteLocalRef(localClass);


			static JNINativeMethod JNIHandler[] = {
				{"NativeUIEvent","(Ljava/lang/String;)V",(void*)NativeUIEvent},
			};

			jni_env->RegisterNatives(UIClass, JNIHandler, sizeof(JNIHandler) / sizeof(JNIHandler[0]));
		}

		std::vector<Json::Value> cacheUIData;

		void add(Json::Value const& val) {
			if (ui_isStopped) {
				mtx.lock();
				cacheUIData.push_back(val);
				mtx.unlock();
				return;
			}

			JNIEnv* jni_env = nullptr;
			bool k = false;
			GameData::VM_0->GetEnv((void**)&jni_env, JNI_VERSION_1_6);
			if (jni_env == nullptr) {
				k = true;
				GameData::VM_0->AttachCurrentThread(&jni_env, NULL);
			}

			jstring str = str2jstring(jni_env, val.toStyledString());
			jmethodID id = jni_env->GetStaticMethodID(UIClass, "NativeCallUI", "(Ljava/lang/String;)V");
			jni_env->CallStaticVoidMethod(UIClass, id, str);

			if (k) {
				GameData::VM_0->DetachCurrentThread();
			}

		}
		void changeState(bool b) {
			ui_isStopped = b;
			mtx.lock();
			if (b == false) {
				for (auto i : cacheUIData) {
					add(i);
				}
				cacheUIData.clear();
			}
			mtx.unlock();
		}
	};

#endif
	void handleJson(Json::Value const& val){
		int id = val["ID"].asInt();
		if(val["Action"].asString() == "View_onClickListener"){
			View *view = (View*)id;
			if(view->onClickListener != nullptr){
				view->onClickListener(view);
			}
		}
		else if(val["Action"].asString() == "View_onLongClickListener"){
			View *view = (View*)id;
			if(view->onLongClickListener != nullptr){
				view->onLongClickListener(view);
			}
		}
		else if(val["Action"].asString() == "EditText_textChangedListener"){
			EditText *et = (EditText*)id;
			et->handle(val["a0"].asString());
		}
		else if (val["Action"].asString() == "Switch_onCheckedChangeListener") {
			Switch* sw = (Switch*)id;
			if (sw->onCheckedChangeListener != nullptr) {
				sw->onCheckedChangeListener(sw,val["State"].asBool());
			}
		}
	}

	
	

	void Init(JavaVM* vm){

#ifdef SOCKET
		interface = new Interface;
		interface->createUIUpdateThread();
		pthread_create(&RecvThread, 0, Recv, 0);

#endif 
#ifdef JNI
		interface = new Interface(vm);

#endif 
		isInited = true;
	}

	void changeUIState(bool v)
	{
		interface->changeState(v);
	}
	void Toast(std::string s){
		Json::Value val;
		val["Action"] = "Toast";
		val["ID"] = 0;
		val["a0"] = s;
		interface->add(val);
	}

	void setMediaVolume(int v)
	{
		Json::Value val;
		val["Action"] = "setMediaVolume";
		val["ID"] = v;
		interface->add(val);
	}

	void playMusic(std::string const& path)
	{
		Json::Value val;
		val["Action"] = "playMusic";
		val["ID"] = 0;
		val["Path"] = path;
		interface->add(val);
	}
	
	Window* Window::newWindow(void){
		Window *win = new Window;
		Json::Value val;
		val["Action"] = "Window_newWindow";
		val["ID"] = (int)win;
		
		interface->add(val);
		return win;
	}
	
	void Window::noLimit(bool v){
		Json::Value val;
		val["Action"] = "Window_noLimit";
		val["ID"] = (int)this;
		val["a0"] = v;
		
		interface->add(val);
	}

	void Window::setCanMove(bool v) {
		Json::Value val;
		val["Action"] = "Window_setCanMove";
		val["ID"] = (int)this;
		val["a0"] = v;

		interface->add(val);
	}
	void Window::addView(View const& view){


		Json::Value val;
		val["Action"] = "Window_addView";
		val["ID"] = (int)this;
		val["a0"] = (int)&view;
		
		interface->add(val);
	}
	void Window::removeView(View const& view){


		Json::Value val;
		val["Action"] = "Window_removeView";
		val["ID"] = (int)this;
		val["a0"] = (int)&view;
		

		interface->add(val);
	}
	void Window::deleteWindow(void){
		Json::Value val;
		val["Action"] = "Window_deleteWindow";
		val["ID"] = (int)this;
		
		interface->add(val);
		delete this;
	}
	void Window::setCanShowKeyboard(bool v){
		Json::Value val;
		val["Action"] = "Window_setCanShowKeyboard";
		val["ID"] = (int)this;
		val["a0"] = v;
		
		interface->add(val);
	}

	void Window::setTouchable(bool v)
	{
		Json::Value val;
		val["Action"] = "Window_setTouchable";
		val["ID"] = (int)this;
		val["a0"] = v;

		interface->add(val);
	}

	void Window::moveTo(int x, int y)
	{
		Json::Value val;
		val["Action"] = "Window_moveTo";
		val["ID"] = (int)this;
		val["X"] = x;
		val["Y"] = y;

		interface->add(val);
	}
	
	void Window::setOrientation(int v){
		Json::Value val;
		val["Action"] = "Window_setOrientation";
		val["ID"] = (int)this;
		val["a0"] = v;
		
		interface->add(val);
	}


	Switch* Switch::newSwitch(void)
	{
		Switch* sw = new Switch;
		Json::Value val;
		val["Action"] = "Switch_newSwitch";
		val["ID"] = (int)sw;

		interface->add(val);
		return sw;
	}

	void Switch::updateData(Json::Value v)
	{
		Json::Value val;
		val["Action"] = "Switch_updateData";
		val["ID"] = (int)this;
		val["a0"] = v;

		interface->add(val);
	}

	void Switch::updateData(std::string s)
	{
		Json::Reader reader;
		Json::Value value;
		reader.parse(s, value);
		updateData(value);
	}

	void Switch::setShowText(bool v)
	{
		Json::Value val;
		val["Action"] = "Switch_setShowText";
		val["ID"] = (int)this;
		val["a0"] = v;

		interface->add(val);
	}

	
	Button* Button::newButton(void){
		Button *btn = new Button;
		Json::Value val;
		val["Action"] = "Button_newButton";
		val["ID"] = (int)btn;
		
		interface->add(val);
		return btn;
	}
	void View::setFocusable(bool v){
		Json::Value val;
		val["Action"] = "View_setFocusable";
		val["ID"] = (int)this;
		val["a0"] = v;
		
		interface->add(val);
	}
	void Button::updateData(Json::Value v){
		Json::Value val;
		val["Action"] = "Button_updateData";
		val["ID"] = (int)this;
		val["a0"] = v;
		
		interface->add(val);
	}
	
	void Button::updateData(std::string s){
		Json::Reader reader;
        Json::Value value;
        reader.parse(s, value);
		updateData(value);
	}
	
	void View::release(void){
		Json::Value val;
		val["Action"] = "View_release";
		val["ID"] = (int)this;

		interface->add(val);
		delete this;
	}
	
	
	TextView* TextView::newTextView(void){
		TextView *tv = new TextView;
		Json::Value val;
		val["Action"] = "TextView_newTextView";
		val["ID"] = (int)tv;
		
		interface->add(val);
		return tv;
	}
	
	void TextView::updateData(Json::Value v){
		Json::Value val;
		val["Action"] = "TextView_updateData";
		val["ID"] = (int)this;
		val["a0"] = v;
		
		interface->add(val);
	}
	
	void TextView::updateData(std::string s){
		Json::Reader reader;
        Json::Value value;
        reader.parse(s, value);
		updateData(value);
	}
	
	EditText* EditText::newEditText(void){
		EditText *et = new EditText;
		
		Json::Value val;
		val["Action"] = "EditText_newEditText";
		val["ID"] = (int)et;
		
		interface->add(val);
		return et;
	}
	
	void EditText::updateData(Json::Value v){
		Json::Value val;
		val["Action"] = "EditText_updateData";
		val["ID"] = (int)this;
		val["a0"] = v;
		
		interface->add(val);
	}
	
	void EditText::updateData(std::string s){
		Json::Reader reader;
        Json::Value value;
        reader.parse(s, value);
		updateData(value);
	}
	
	
	ImageView* ImageView::newImageView(std::string Path){
		ImageView *im = new ImageView;
		Json::Value val;
		val["Action"] = "ImageView_newImageView";
		val["ID"] = (int)im;
		val["a0"] = Path;
		
		interface->add(val);
		return im;
	}


	LinearLayout* LinearLayout::newLinearLayout(void)
	{
		LinearLayout* ll = new LinearLayout;

		Json::Value val;
		val["Action"] = "LinearLayout_newLinearLayout";
		val["ID"] = (int)ll;

		interface->add(val);
		return ll;
	}
	void LinearLayout::addView(View const& view)
	{
		Json::Value val;
		val["Action"] = "LinearLayout_addView";
		val["ID"] = (int)this;
		val["a0"] = (int)&view;

		interface->add(val);
	}
	void LinearLayout::removeView(View const& view)
	{
		Json::Value val;
		val["Action"] = "LinearLayout_removeView";
		val["ID"] = (int)this;
		val["a0"] = (int)&view;

		interface->add(val);
	}
	void LinearLayout::setBackground(std::string const& path)
	{
		Json::Value val;
		val["Action"] = "LinearLayout_setBackground";
		val["ID"] = (int)this;
		val["a0"] = path;

		interface->add(val);
	}
	void LinearLayout::setOrientation(int v)
	{
		Json::Value val;
		val["Action"] = "LinearLayout_setOrientation";
		val["ID"] = (int)this;
		val["a0"] = v;

		interface->add(val);
	}
}

