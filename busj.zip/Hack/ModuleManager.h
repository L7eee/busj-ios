#pragma once
#include <vector>
#include <stdio.h>
#include <jni.h>
#include "json/json.h"
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <stdlib.h>
#include "MCPE/SDK/Actor.h"
#include "MCPE/SDK/Packet.h"
#include "MCPE/SDK/Render.h"
#include "MCPE/SDK/MinecraftGame.h"
#include <memory>
#include <mutex>
#include <shared_mutex>

#define Internal
//#define HideUI
//#define T3


class Module;
class ModuleManager;

class ConfigObject {
public:
	void* ptr;
	std::string configName;
	std::string type;
	std::string moduleName;
	ConfigObject(void* val, std::string name, Module* m, std::string typeName);
};

class Module {
public:
	std::vector<ConfigObject*> configList;

	template <typename TRet>
	void addConfig(TRet* object, std::string const& name) {
		ConfigObject* conf = new ConfigObject(object, name, this, typeid(TRet).name());
		configList.push_back(conf);
	}

	void loadConfig(Json::Value const& config);
	void saveConfig(Json::Value& config);
	ConfigObject* getConfigObject(std::string const& name);

	void logMessage(std::string const& message);
	virtual void MinecraftInit();
	virtual void UiInit();
	virtual const char* GetName();
	virtual void OnTick(Actor* act);
	virtual void OnSendPacket(Packet* packet);
	virtual void AfterPacket(Packet* packet);
	virtual void OnRender(MinecraftUIRenderContext* ctx);
	virtual void OnCmd(std::vector<std::string>* cmd);
	virtual void OnAttack(GameMode* object,Actor* act);
	virtual void OnBuild(GameMode* object,BlockPos const& pos,int rot);
	virtual void OnNewGame(std::string const& ip);
	virtual void OnSendChat(std::string const& msg);
	virtual void OnMCMainThreadTick(MinecraftGame* mcgame);
};

class ConfigLoader {
public:
	std::string getPath();
	void load(ModuleManager* manager);
	void save(ModuleManager* manager);
};



class ModuleManager {
public:
	ConfigLoader* loader;

	void executeModuleCommand(std::string const& s);

	void init();
	void initModules();
	ModuleManager();
	std::vector<std::shared_ptr<Module>> ModuleList;
	void jniOnLoad(JavaVM* vm);

	template <typename TRet>
	TRet* getModule() {
		for (auto pMod : ModuleList) {
			if (auto pRet = dynamic_cast<typename std::remove_pointer<TRet>::type*>(pMod.get())) {

				return pRet;
			}
		}
		return nullptr;
	};

	template <typename TRet>
	std::vector<TRet*> getModules() {
		std::vector<TRet*> result;
		for (auto pMod : ModuleList) {
			if (auto pRet = dynamic_cast<typename std::remove_pointer<TRet>::type*>(pMod.get())) {
				result.push_back(pRet);
			}
		}
		return result;
	};

	bool executedCMD = false;
	bool canUseCommand = false;

	void OnNewGame(std::string const& ip);
};

extern ModuleManager* moduleManager;


