#include "ContainerHack.h"
#include "MCPE/GameData.h"
#include "Android.h"

ContainerHack::ContainerHack()
{
	ModuleType = "Item";

	UIType = 2;
	MenuCall = ([]() {
		ContainerHack* containerHack = moduleManager->getModule<ContainerHack>();
		if (containerHack->HookClosePacket) {
			containerHack->tryClose();
			Android::Toast("Close Container");
		}
		else {
			containerHack->HookClosePacket = true;
			Android::Toast("Hook Container");
		}
	});
}

const char* ContainerHack::GetName()
{
	return "ContainerHack";
}

void ContainerHack::tryClose(void) {
	HookClosePacket = false;
	if (isContainerOpened == true) {
		isContainerOpened = false;
		ContainerClosePacket closep(containerID);
		isMySender = true;
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->sendNetworkPacket(closep);
	}
}

void ContainerHack::OnCmd(std::vector<std::string>* cmd)
{
	if ((*cmd)[0] == ".ContainerClose") {
		if (cmd->size() < 2)return;
		if ((*cmd)[1] == "true") {
			moduleManager->executedCMD = true;
			HookClosePacket = true;
		}
		else if ((*cmd)[1] == "false") {
			moduleManager->executedCMD = true;
			tryClose();
		}
	}
}


void ContainerHack::OnSendPacket(Packet* packet)
{
	
	if (packet->getName() == "ContainerClosePacket") {
		ContainerClosePacket* closeptr = (ContainerClosePacket*)(packet);
		containerID = closeptr->ContainerID;
		if (HookClosePacket == true) {
			if (isMySender == false) {
				isContainerOpened = true;
				MCHook::noPacketThisTime = true;
			}
			else {
				isMySender = false;
			}
		}
	}
}
