
#ifndef _UI_H
#define _UI_H

#include <vector>
#include <string>
#include <stdio.h>
#include "jni.h"
#include "MCPE/SDK/Actor.h"
#include "json/json.h"
#include <functional>
#include "ByOpen/byopen.h"


#define SOCKET


namespace Android{
	void loadLibrary(std::string const& libname);
	void setMediaVolume(int v);
	void playMusic(std::string const& path);
	void Toast(std::string s);
	std::string getHWId();

	void changeUIState(bool v);

	void handleJson(Json::Value const& val);

	extern bool isInited;
	
	void Init(JavaVM* vm);
	
	class View{
		public:
		void setOnClickListener(std::function<void(View*)>);
		std::function<void(View*)> onClickListener = nullptr;
		void setOnLongClickListener(std::function<void(View*)>);
		std::function<void(View*)> onLongClickListener = nullptr;
		void release(void);
		void setFocusable(bool v);
	};
	
	
	class Button:public View{
		public:
		static Button* newButton(void);
		void updateData(Json::Value val);
		void updateData(std::string s);
	};
	
	class TextView:public View{
		public:
		static TextView* newTextView(void);
		void updateData(Json::Value val);
		void updateData(std::string s);
	};
	
	class EditText:public View{
		public:
		static EditText* newEditText(void);
		void updateData(Json::Value val);
		void updateData(std::string s);	
		void setTextChangedListener(std::function<void(EditText*, std::string)>);
		std::function<void(EditText*,std::string)> textChangedListener = nullptr;	
		void handle( std::string s);
		std::string text = "";
	};
	
	class ImageView:public View{
		public:
		static ImageView* newImageView(std::string ImagePath);
	};

	class Switch :public View {
	public:
		static Switch* newSwitch(void);
		void updateData(Json::Value val);
		void updateData(std::string s);
		void setShowText(bool v);
		void setOnCheckedChangeListener(std::function<void(Switch*,bool)>);
		std::function<void(Switch*,bool)> onCheckedChangeListener = nullptr;
	};

	class LinearLayout :public View {
	public:
		static LinearLayout* newLinearLayout(void);
		void addView(View const& view);
		void removeView(View const& view);
		void setBackground(std::string const& path);
		void setOrientation(int v);
	};
	
	class Window{
		public:
		int id;
		static Window* newWindow(void);
		void noLimit(bool v);
		void setCanMove(bool v);
		void addView(View const& view);
		void removeView(View const& view);
		void deleteWindow(void);
		void setCanShowKeyboard(bool v);
		void setOrientation(int v);
		void setTouchable(bool v);
		void moveTo(int x, int y);
	};
	
}

#endif