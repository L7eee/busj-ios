#include "ClickDestroy.h"
#include "MCPE/GameData.h"
#include "Android.h"
#include "HackSDK.h"

ClickDestroy::ClickDestroy()
{
	addConfig(&range, "range");

	ModuleType = "World";
	UIType = 0;
	enable_ptr = &enabled;
}

void destroy(BlockPos const& start, BlockPos const& end, int8_t rot) {
	GameMode* obj = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->gamemode;
	int x = 0;
	int y = 0;
	int z = 0;
	for (x = start.x; x <= end.x; x = x + 1) {
		for (y = start.y; y <= end.y; y = y + 1) {
			for (z = start.z; z <= end.z; z = z + 1) {
				BlockPos targetPos;
				targetPos.x = x;
				targetPos.y = y;
				targetPos.z = z;

				HackSDK::destroyBlock(targetPos, rot);
			}
		}
	}
}

void ClickDestroy::OnBuild(GameMode* object, BlockPos const& pos, int rot)
{

	if (enabled == false || GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->gamemode != object)return;
	
		MCHook::noBuildThisTime = true;
		if (range == 0)return;
		BlockPos start;
		start.x = pos.x - range + 1;
		start.y = pos.y - range + 1;
		start.z = pos.z - range + 1;
		BlockPos end;
		end.x = pos.x + range - 1;
		end.y = pos.y + range - 1;
		end.z = pos.z + range - 1;
		destroy(start, end, rot);
	
}

const char* ClickDestroy::GetName()
{
	return "ClickDestroy";
}





void ClickDestroy::OnCmd(std::vector<std::string>* cmd)
{
	if ((*cmd)[0] == ".ClickDestroy") {
		if (cmd->size() < 2)return;
		if ((*cmd)[1] == "config") {
			if (cmd->size() < 3)return;
			moduleManager->executedCMD = true;
			range = atoi((*cmd)[2].c_str());
		}
		else if ((*cmd)[1] == "true") {
			moduleManager->executedCMD = true;
			enabled = true;
		}
		else if ((*cmd)[1] == "false") {
			moduleManager->executedCMD = true;
			enabled = false;
		}
	}
}


void ClickDestroy::initViews() {
	Android::EditText* Click_Range = Android::EditText::newEditText();
	UIUtils::updateEditTextData(Click_Range, "Range");

	Android::TextView * Click_save = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Click_save, "Save", "#FF8800", 19);
	Click_save->setOnClickListener([=](Android::View*) {
		if (Click_Range->text == "")return;
		Android::Toast("Click配置已保存");
		range = UIUtils::et_getInt(Click_Range);
	});

	SecondWindowList.push_back(Click_save);
	SecondWindowList.push_back(Click_Range);
}