﻿#include "Pos.h"
#include "MCPE/GameData.h"
#include "Android.h"
#include "HackSDK.h"

Pos::Pos()
{
	addConfig(&enabled, "enabled");

	ModuleType = "Render";

	UIType = 2;
	MenuCall = ([=]() {
		if (enabled) {
			Android::Toast("ShowPos disabled");
			ShowPos(false);
		}
		else {
			Android::Toast("ShowPos enabled");
			ShowPos(true);
		}
	});
}

const char* Pos::GetName()
{
	return "Pos";
}



void Pos::MinecraftInit()
{
	f.addFunction((uint32_t)GameData::FunctionPtr::CISM_shouldDisplayPlayerPosition - 1);
	f.killAll();
}

void Pos::ShowPos(bool v) {
	enabled = v;
	if (v == true) {
		f.killAll(1);
	}
	else {
		f.killAll(0);
	}
}


void Pos::OnCmd(std::vector<std::string>* cmd)
{
	if ((*cmd)[0] == ".ShowPos") {
		if (cmd->size() < 2)return;
		if ((*cmd)[1] == "true") {
			moduleManager->executedCMD = true;
			ShowPos(true);
		}
		else if ((*cmd)[1] == "false") {
			moduleManager->executedCMD = true;
			ShowPos(false);
		}
	}
}

