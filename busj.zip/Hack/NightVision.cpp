﻿#include "NightVision.h"
#include "MCPE/GameData.h"
#include "Android.h"

NightVision::NightVision()
{
	addConfig(&enabled, "enabled");

	ModuleType = "Render";
	UIType = 0;
	enable_ptr = &enabled;
}

const char* NightVision::GetName()
{
	return "NightVision";
}



void NightVision::OnTick(Actor* obj)
{
	if (enabled == false || obj != GameData::getNowMinecraftGame()->getPrimaryLocalPlayer())return;
	MobEffectInstance effect;
	CompoundTag tag;
	tag.putByte("Id", 16);
	tag.putByte("Amplifier", 1);
	tag.putInt("Duration", 4);
	tag.putInt("DurationEasy", 4);
	tag.putInt("DurationNormal", 4);
	tag.putInt("DurationHard", 4);
	tag.putBoolean("Ambient", false);
	tag.putBoolean("ShowParticles", false);
	tag.putBoolean("DisplayOnScreenTextureAnimation", false);
	effect.load(tag);
	obj->addEffect(effect);
}

void NightVision::OnCmd(std::vector<std::string>* cmd)
{
	if ((*cmd)[0] == ".NightVision") {
		if (cmd->size() < 2)return;
		if ((*cmd)[1] == "true") {
			moduleManager->executedCMD = true;
			enabled = true;
		}
		else if ((*cmd)[1] == "false") {
			moduleManager->executedCMD = true;
			enabled = false;
		}
	}
}

