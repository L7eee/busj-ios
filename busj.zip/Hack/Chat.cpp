#include "Chat.h"
#include "MCPE/GameData.h"
#include "Android.h"
#include <math.h>
#include "Chat.h"
#include "Network.h"
#include "Utils.hpp"

Chat::Chat()
{
	addConfig(&antiSpamming, "antiSpamming");
	addConfig(&HideChat, "HideChat");

	ModuleType = "Other";
	UIType = 1;
}

const char* Chat::GetName()
{
	return "Chat";
}

void Chat::OnCmd(std::vector<std::string>* cmd)
{
	if ((*cmd)[0] == ".HideChat") {
		if (cmd->size() < 2)return;
		if ((*cmd)[1] == "true") {
			moduleManager->executedCMD = true;
			HideChat = true;
		}
		else if ((*cmd)[1] == "false") {
			moduleManager->executedCMD = true;
			HideChat = false;
		}
	}
	else if ((*cmd)[0] == ".AntiSpamming") {
		if (cmd->size() < 2)return;
		if ((*cmd)[1] == "true") {
			moduleManager->executedCMD = true;
			antiSpamming = true;
		}
		else if ((*cmd)[1] == "false") {
			moduleManager->executedCMD = true;
			antiSpamming = false;
		}
	}
}

void Chat::initViews()
{
	Android::TextView* Chat_HideChat = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Chat_HideChat, "HideChat", "#FF8800", 19);
	Chat_HideChat->setOnClickListener([](Android::View*) {
		Chat* chat = moduleManager->getModule<Chat>();
		if (chat->HideChat) {
			Android::Toast("HideChat false!");
			chat->HideChat = false;
		}
		else {
			Android::Toast("HideChat true!");
			chat->HideChat = true;
		}
	});

	Android::TextView* Chat_antiSpamming = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Chat_antiSpamming, "antiSpamming", "#FF8800", 19);
	Chat_antiSpamming->setOnClickListener([=](Android::View*) {
		if (antiSpamming) {
			Android::Toast("AntiSpamming false!");
			antiSpamming = false;
		}
		else {
			Android::Toast("AntiSpamming true!");
			antiSpamming = true;
		}
	});

	SecondWindowList.push_back(Chat_HideChat);
	SecondWindowList.push_back(Chat_antiSpamming);
}


void* (*old_CNH_handle)(void* ClientNetworkHandler, void* NetworkIdentifier, TextPacket const& _packet);

void* CNH_handle(void* ClientNetworkHandler, void* NetworkIdentifier, TextPacket const& _packet) {
	TextPacket& wpacket = (TextPacket&)_packet;

	Chat* chat = moduleManager->getModule<Chat>();

	if (chat->HideChat == true) {
		return nullptr;
	}

	Network* network = moduleManager->getModule<Network>();
	if (network) {
		if (network->showChat(&wpacket) == false) {
			return nullptr;
		}
	}
	
	if (chat->antiSpamming == true) {
		if (Utils::match(wpacket.getChatMessage().c_str(), "§") > 7 || wpacket.getChatMessage().size() > 55 * 3) {
			wpacket.getChatMessage() = "尝试刷屏已被屏蔽";
		}
		if (Utils::match(wpacket.getPlayerName().c_str(), "§") > 7 || wpacket.getPlayerName().size() > 16 * 3) {
			wpacket.getPlayerName() = "尝试刷屏已被屏蔽";
		}
		return (*old_CNH_handle)(ClientNetworkHandler, NetworkIdentifier, _packet);
	}
	else {
		return (*old_CNH_handle)(ClientNetworkHandler, NetworkIdentifier, _packet);
	}
}

void Chat::MinecraftInit()
{
	uint32_t address = (uint32_t)GameData::FunctionPtr::CNH_handle_TextPacket;
	registerInlineHook(address, (uint32_t)CNH_handle, (uint32_t**)&old_CNH_handle);
	inlineHook(address);

}
