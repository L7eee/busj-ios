#include "PyManager.h"
#include "MCPE/GameData.h"
#include "Android.h"
#include "Utils.hpp"
#include "pyport.h"
#include "object.h"
#include "FunctionTool/FunctionTool.h"
#include "Python.h"
#include "HackSDK.h"
#include "frameobject.h"
extern "C" void MCPDump(FILE * fp, PyObject * co, void* call);
extern "C" void repairMCPOPCodes(FILE * fp,uint32_t v);

void dumpCode(const char* path, PyObject* co) {
	auto res = Utils::split(path, "/");
	res.pop_back();
	std::stringstream Path;
	for (auto i : res) {
		Path << "/" << i;
	}
	Utils::folder_mkdirs(Path.str().c_str());
	FILE* fp = fopen(path, "wb+");
	uint32_t  MAGIC = (62211 | ((long)'\r' << 16) | ((long)'\n' << 24));
	fwrite(&MAGIC, 4, 1, fp);
	uint32_t n = 0;
	fwrite(&n, 4, 1, fp);
	MCPDump(fp, co, GameData::FunctionPtr::w_object);
	repairMCPOPCodes(fp,((PyCodeObject*)co)->a);
	fclose(fp);
}

void* (*old_fop_new_module)(void*, PyCodeObject*, void*);
void* now_fop_new_module(void* v1, PyCodeObject* co, void* v3) {
	std::string PyPath = PyString_AsString(co->co_filename);
	std::stringstream os;
	os << "/sdcard/MCP/" << PyPath << "c";
	dumpCode(os.str().c_str(), (PyObject*)co);

	return (*old_fop_new_module)(v1, co, v3);
}

void PyManager::MinecraftInit()
{
	if (access("/data/data/com.netease.x19/files/games/com.netease/venilla.mcp",F_OK) == 0) {
		const char* t = "/venilla.mcp";
		FunctionTool::WriteDataToCode((void*)(GameData::libinfo.head + 0x3EA2F99), (void*)t, strlen(t));
	}
	if (access("/sdcard/slt.mcp", F_OK) == 0 && access("/data/data/com.netease.x19/files/games/com.netease/slt.mcp", F_OK) != 0) {
		Utils::copyFile("/sdcard/slt.mcp", "/data/data/com.netease.x19/files/games/com.netease/slt.mcp");
	}
	if (access("/data/data/com.netease.x19/files/games/com.netease/slt.mcp", F_OK) == 0) {
		const char* t = "slt.mcp";
		FunctionTool::WriteDataToCode((void*)(GameData::libinfo.head + 0x3EB4EE2), (void*)t, strlen(t));
	}

	HackSDK::FastHook(GameData::FunctionPtr::const_fop_new_module, (void*)now_fop_new_module, (void**)&old_fop_new_module);
}


PyManager::PyManager()
{
}


