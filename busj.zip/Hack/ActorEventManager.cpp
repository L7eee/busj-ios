#include "ActorEventManager.h"
#include "MCPE/GameData.h"
#include "HackSDK.h"
#include "Utils.hpp"

std::string ActorEventManager::int64_len(int64_t t) {
	std::string T;
	std::stringstream os;
	os << t;
	T.push_back((char)os.str().size());
	std::stringstream os1;
	os1 << T << t;
	return os1.str();
}

void ActorEventManager::updatePetsData(std::string const& petName, std::string const& modelName)
{
	deleteMobs(true);
	GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->getDimension()->forEachPlayer([&](Player& object) {
		std::string A;
		A.push_back((char)modelName.size());
		std::string B;
		B.push_back((char)petName.size());
		std::stringstream data;

		data << Utils::hex2string("82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 93 C4 0B 4D 6F 64 45 76 65 6E 74 43 32 53 82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 94 C4 09 4D 69 6E 65 63 72 61 66 74 C4 03 70 65 74 C4 12 73 75 6D 6D 6F 6E 5F 70 65 74 5F 72 65 71 75 65 73 74 87 C4 13 61 6C 6C 6F 77 5F 73 74 65 70 5F 6F 6E 5F 62 6C 6F 63 6B C2 C4 0B 61 76 6F 69 64 5F 6F 77 6E 65 72 C3 C4 07 73 6B 69 6E 5F 69 64 CD 27 11 C4 09 70 6C 61 79 65 72 5F 69 64 C4")<< int64_len((int64_t)*object.getUniqueID())<< Utils::hex2string("C4 06 70 65 74 5F 69 64 01 C4 0A 6D 6F 64 65 6C 5F 6E 61 6D 65 C4") << A << modelName << Utils::hex2string("C4 04 6E 61 6D 65 C4") << B << petName << Utils::hex2string("C0");
		PyRpcPacket p(data.str());
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->sendNetworkPacket(p);
		return true;
	});
}

void ActorEventManager::setModel(Actor* act, std::string const& modelName)
{
	std::stringstream data;
	std::string A;
	A.push_back((char)modelName.size());
	LocalPlayer* lp = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer();
	data << Utils::hex2string("82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 93 C4 0B 4D 6F 64 45 76 65 6E 74 43 32 53 82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 94 C4 09 4D 69 6E 65 63 72 61 66 74 C4 03 70 65 74 C4 17 63 68 61 6E 67 65 5F 70 65 74 5F 73 6B 69 6E 5F 72 65 71 75 65 73 74 84 C4 09 70 6C 61 79 65 72 5F 69 64 C4")<< int64_len((int64_t)*lp->getUniqueID()) << Utils::hex2string("C4 07 73 6B 69 6E 5F 69 64 CD 27 11 C4 0E 63 75 72 72 65 6E 74 5F 70 65 74 5F 69 64 C4") << int64_len((int64_t)*act->getUniqueID()) << Utils::hex2string("C4 0A 6D 6F 64 65 6C 5F 6E 61 6D 65 C4") << A << modelName << Utils::hex2string("C0");
	PyRpcPacket p(data.str());
	GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->sendNetworkPacket(p);
}

void ActorEventManager::updateModels(bool self, bool mob, std::string const& modelName)
{
	auto lp = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer();
	if (self) {
		setModel(lp, modelName);
	}
	else {
		auto list = HackSDK::getActorList();
		for (auto i : list) {
			if (i == lp)continue;
			if (!mob && ActorClassTree::isInstanceOf(*i, 63) == false)continue;
			setModel(i, modelName);
		}
	}
}

void ActorEventManager::playAnimation(bool self, std::string const& animation)
{
	LocalPlayer* lp = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer();
	if (self) {
		std::string A;
		A.push_back((char)animation.size());
		std::stringstream data;
		data << Utils::hex2string("82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 93 C4 0B 4D 6F 64 45 76 65 6E 74 43 32 53 82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 94 C4 09 4D 69 6E 65 63 72 61 66 74 C4 05 65 6D 6F 74 65 C4 0E 50 6C 61 79 45 6D 6F 74 65 45 76 65 6E 74 83 C4 08 70 6C 61 79 65 72 49 64 C4") << int64_len((int64_t)*lp->getUniqueID()) << Utils::hex2string("C4 08 61 6E 69 6D 4E 61 6D 65 C4")<<A<<animation<<Utils::hex2string("C4 04 76 69 65 77 00 C0");
		PyRpcPacket p(data.str());
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->sendNetworkPacket(p);
	}
	else {

		lp->getDimension()->forEachPlayer([&](Player& object) {
			if (&object == lp)return true;
			std::string A;
			A.push_back((char)animation.size());
			std::stringstream data;
			data << Utils::hex2string("82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 93 C4 0B 4D 6F 64 45 76 65 6E 74 43 32 53 82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 94 C4 09 4D 69 6E 65 63 72 61 66 74 C4 05 65 6D 6F 74 65 C4 0E 50 6C 61 79 45 6D 6F 74 65 45 76 65 6E 74 83 C4 08 70 6C 61 79 65 72 49 64 C4") << int64_len((int64_t)*object.getUniqueID()) << Utils::hex2string("C4 08 61 6E 69 6D 4E 61 6D 65 C4") << A << animation << Utils::hex2string("C4 04 76 69 65 77 00 C0");
			PyRpcPacket p(data.str());
			GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->sendNetworkPacket(p);
			return true;
		});
	}
}



void ActorEventManager::dimensionBag(int dim)
{
	LocalPlayer* p = GameData::getNowMinecraftGame()->getPrimaryLocalPlayer();
	for (int i = 0; i != 36; i = i + 1) {
		std::stringstream data;
		std::string s1;
		s1.push_back((char)i);
		std::string s2;
		s2.push_back((char)(i + 35 * (dim - 1)));
		data << Utils::hex2string("82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 93 C4 0B 4D 6F 64 45 76 65 6E 74 43 32 53 82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 94 C4 09 4D 69 6E 65 63 72 61 66 74 C4 03 70 65 74 C4 11 73 77 61 70 5F 70 65 74 5F 62 61 67 5F 69 74 65 6D 86 C4 08 70 6C 61 79 65 72 49 64 C4") << int64_len(*p->getUniqueID()) << Utils::hex2string("C4 0B 74 61 6B 65 50 65 72 63 65 6E 74 01 C4 08 66 72 6F 6D 53 6C 6F 74") << s1 << Utils::hex2string("C4 06 74 6F 49 74 65 6D C0 C4 06 74 6F 53 6C 6F 74 C4 08 69 74 65 6D 42 74 6E") << s2 << Utils::hex2string("C4 08 66 72 6F 6D 49 74 65 6D C0 C0");
		PyRpcPacket p(data.str());
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->sendNetworkPacket(p);
	}
	
}



void ActorEventManager::deleteMobs(bool pet)
{
	GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->getDimension()->getEntityIdMap()->forEachEntity([=](Actor& object) {
		if (pet) {
			if (object.getModelName() == "") {
				return;
			}
		}
		std::stringstream data;
		data << Utils::hex2string("82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 93 C4 0B 4D 6F 64 45 76 65 6E 74 43 32 53 82 C4 08 5F 5F 74 79 70 65 5F 5F C4 05 74 75 70 6C 65 C4 05 76 61 6C 75 65 94 C4 09 4D 69 6E 65 63 72 61 66 74 C4 03 70 65 74 C4 14 64 65 73 74 72 6F 79 5F 70 65 74 73 5F 72 65 71 75 65 73 74 82 C4 0A 65 6E 74 69 74 79 5F 69 64 73 91 C4") << int64_len((int64_t)*object.getUniqueID()) << Utils::hex2string("C4 09 70 6C 61 79 65 72 5F 69 64 C4") << int64_len((int64_t)*GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->getUniqueID()) << Utils::hex2string("C0");
		PyRpcPacket p(data.str());
		GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->sendNetworkPacket(p);
	});
}

ActorEventManager::ActorEventManager()
{
	addConfig(&clickModel, "clickModel");
	addConfig(&clickModelName, "clickModelName");

	ModuleType = "World";
	UIType = 1;

}

const char* ActorEventManager::GetName()
{
	return "ActorEventManager";
}


void ActorEventManager::OnCmd(std::vector<std::string>* cmd)
{
#ifdef Internal
	  if ((*cmd)[0] == ".DeleteMobs") {
		 moduleManager->executedCMD = true;
		 deleteMobs(false);
	 }
	 else if ((*cmd)[0] == ".ClickModel") {
		 if (cmd->size() < 2)return;
		 if ((*cmd)[1] == "true") {
			 moduleManager->executedCMD = true;
			 clickModel = true;
		 }
		 else if ((*cmd)[1] == "false") {
			 moduleManager->executedCMD = true;
			 clickModel = false;
		 }
		 if (cmd->size() < 3)return;
		 clickModelName = (*cmd)[2];
	 }
	 else if ((*cmd)[0] == ".UpdatePetsData") {
		 if (cmd->size() < 3)return;
		 moduleManager->executedCMD = true;
		 updatePetsData((*cmd)[1], (*cmd)[2]);
	 }
	 else if ((*cmd)[0] == ".UpdateModels") {
		 if (cmd->size() < 4)return;
		 moduleManager->executedCMD = true;
		 bool self = false;
		 bool mob = false;
		 if ((*cmd)[1] == "true") {
			 self = true;
		 }
		 else if ((*cmd)[1] == "false") {
			 self = false;
		 }
		 if ((*cmd)[2] == "true") {
			 mob = true;
		 }
		 else if ((*cmd)[2] == "false") {
			 mob = false;
		 }
		 updateModels(self, mob, (*cmd)[3]);
	 }
	 else if ((*cmd)[0] == ".PlayAnimation") {
		 if (cmd->size() < 2)return;
		 moduleManager->executedCMD = true;
		 bool self = false;
		 if (cmd->size() >= 3) {
			 if ((*cmd)[2] == "true") {
				 self = true;
			 }
			 else if ((*cmd)[2] == "false") {
				 self = false;
			 }
		 }
		 playAnimation(self, (*cmd)[1]);
	 }
	 else if ((*cmd)[0] == ".DimensionBag") {
		 if (cmd->size() < 2)return;
		 moduleManager->executedCMD = true;
		 dimensionBag(atoi((*cmd)[1].c_str()));
	 }
#endif
}

void ActorEventManager::initViews()
{

	Android::TextView* DeleteMobs = Android::TextView::newTextView();
	UIUtils::updateTextViewData(DeleteMobs, "DeleteMobs", "#FF8800", 19);
	DeleteMobs->setOnClickListener([=](Android::View*) {
		if (GameData::getNowMinecraftGame()->isInGame()) {
			Android::Toast("已清除实体!");
			moduleManager->getModule<HackSDK>()->addLocalPlayerTickEvent([=]() {
				deleteMobs(false);
			});
		}
	});


	Android::EditText* Pet_Name = Android::EditText::newEditText();
	UIUtils::updateEditTextData(Pet_Name, "PetName");

	Android::EditText* Pet_ModelName = Android::EditText::newEditText();
	UIUtils::updateEditTextData(Pet_ModelName, "PetModelName");

	Android::TextView* Pet_update = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Pet_update, "UpdatePets", "#FF8800", 19);
	Pet_update->setOnClickListener([=](Android::View*) {
		if (GameData::getNowMinecraftGame()->isInGame() == false)return;
		Android::Toast("修改宠物数据成功");
		moduleManager->getModule<HackSDK>()->addLocalPlayerTickEvent([=]() {
			updatePetsData(Pet_Name->text, Pet_ModelName->text);
		});
	});
	
	Android::EditText* Model_Self = Android::EditText::newEditText();
	UIUtils::updateEditTextData(Model_Self, "Self");

	Android::EditText* Model_Mob = Android::EditText::newEditText();
	UIUtils::updateEditTextData(Model_Mob, "Mob");

	Android::EditText* Model_ModelName = Android::EditText::newEditText();
	UIUtils::updateEditTextData(Model_ModelName, "Model");

	Android::TextView* Model_UpdateModel = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Model_UpdateModel, "UpdateModel", "#FF8800", 19);
	Model_UpdateModel->setOnClickListener([=](Android::View*) {
		if (GameData::getNowMinecraftGame()->isInGame() == false)return;
		Android::Toast("修改模型数据成功");
		moduleManager->getModule<HackSDK>()->addLocalPlayerTickEvent([=]() {
			updateModels(UIUtils::et_getBool(Model_Self), UIUtils::et_getBool(Model_Mob), Model_ModelName->text);
		});
	});

	Android::EditText* Animation_self = Android::EditText::newEditText();
	UIUtils::updateEditTextData(Animation_self, "self");

	Android::EditText* Animation_name = Android::EditText::newEditText();
	UIUtils::updateEditTextData(Animation_name, "name");

	Android::TextView* Animation = Android::TextView::newTextView();
	UIUtils::updateTextViewData(Animation, "PlayAnimation", "#FF8800", 19);
	Animation->setOnClickListener([=](Android::View*) {
		if (GameData::getNowMinecraftGame()->isInGame() == false)return;
		Android::Toast("播放动作成功");
		moduleManager->getModule<HackSDK>()->addLocalPlayerTickEvent([=]() {
			playAnimation(UIUtils::et_getBool(Animation_self), Animation_name->text);
		});
	});
	Android::EditText* DimensionBag_Dimension = Android::EditText::newEditText();
	UIUtils::updateEditTextData(DimensionBag_Dimension, "Dimension(1-7)");

	Android::TextView* DimensionBag = Android::TextView::newTextView();
	UIUtils::updateTextViewData(DimensionBag, "DimensionBag", "#FF8800", 19);
	DimensionBag->setOnClickListener([=](Android::View*) {
		if (GameData::getNowMinecraftGame()->isInGame() == false)return;
		if (DimensionBag_Dimension->text == "")return;
		Android::Toast("放置物品成功");
		moduleManager->getModule<HackSDK>()->addLocalPlayerTickEvent([=]() {
			dimensionBag(UIUtils::et_getInt(DimensionBag_Dimension));
		});
	});
#ifdef Internal
	SecondWindowList.push_back(DeleteMobs);
	SecondWindowList.push_back(Pet_Name);
	SecondWindowList.push_back(Pet_ModelName);
	SecondWindowList.push_back(Pet_update);
	SecondWindowList.push_back(UIUtils::createSimpleEditTextWithString(&clickModelName, "ClickModelName"));
	SecondWindowList.push_back(UIUtils::createSimpleTextViewWithBool(&clickModel, "ClickModel"));
	SecondWindowList.push_back(Model_Self);
	SecondWindowList.push_back(Model_Mob);
	SecondWindowList.push_back(Model_ModelName);
	SecondWindowList.push_back(Model_UpdateModel);
	SecondWindowList.push_back(Animation_name);
	SecondWindowList.push_back(Animation_self);
	SecondWindowList.push_back(Animation);
	SecondWindowList.push_back(DimensionBag_Dimension);
	SecondWindowList.push_back(DimensionBag);
#endif
}

void ActorEventManager::OnAttack(GameMode* object, Actor* act)
{
	if (object == GameData::getNowMinecraftGame()->getPrimaryLocalPlayer()->gamemode) {
		if (clickModel) {
			MCHook::noAttackThisTime = true;
			setModel(act, clickModelName);
		}
	}
}
