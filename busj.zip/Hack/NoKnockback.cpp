﻿#include "NoKnockback.h"
#include "MCPE/GameData.h"
#include "Android.h"
#include "HackSDK.h"

NoKnockback::NoKnockback()
{
	addConfig(&enabled, "enabled");

	ModuleType = "PVP";
	UIType = 0;
	enable_ptr = &enabled;
}

const char* NoKnockback::getMenuName()
{
	return "NoKnockback(NetworkGame)";
}

const char* NoKnockback::GetName()
{
	return "NoKnockback";
}

void* (*old_LCNH_handle)(void* LegacyClientNetworkHandler, void* NetworkIdentifier, Packet const& _SetActorMotionPacket);

void* LCNH_handle(void* LegacyClientNetworkHandler, void* NetworkIdentifier, Packet const& _SetActorMotionPacket) {
	if (moduleManager->getModule<NoKnockback>()->enabled) {
		return nullptr;
	}
	else {
		return (*old_LCNH_handle)(LegacyClientNetworkHandler, NetworkIdentifier, _SetActorMotionPacket);
	}
}


void NoKnockback::MinecraftInit()
{
	uint32_t address = (uint32_t)GameData::FunctionPtr::LCNH_handle_SetActorMotionPacket;
	registerInlineHook(address, (uint32_t)LCNH_handle, (uint32_t**)&old_LCNH_handle);
	inlineHook(address);
}



void NoKnockback::OnCmd(std::vector<std::string>* cmd)
{
	if ((*cmd)[0] == ".NoKnockback") {
		if (cmd->size() < 2)return;
		if ((*cmd)[1] == "true") {
			moduleManager->executedCMD = true;
			enabled = true;
		}
		else if ((*cmd)[1] == "false") {
			moduleManager->executedCMD = true;
			enabled = false;
		}
	}
}

